
<?php $__env->startSection('title','Donate'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="card">
    <h1 style="margin-top:0;">Donate</h1>
    <p style="color:var(--cool-gray)">Support our initiatives.</p>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DLA\digital-leap-africa\digital-leap-africa\resources\views\donate.blade.php ENDPATH**/ ?>