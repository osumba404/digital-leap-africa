<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-danger fw-semibold text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\DLA\digital-leap-africa\digital-leap-africa\resources\views\components\danger-button.blade.php ENDPATH**/ ?>