<a {{ $attributes->merge(['class' => 'dropdown-item']) }}>{{ $slot }}</a>
