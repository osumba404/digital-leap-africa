@extends('layouts.app')
@section('title','Donate')
@section('content')
<div class="container">
  <div class="card">
    <h1 style="margin-top:0;">Donate</h1>
    <p style="color:var(--cool-gray)">Support our initiatives.</p>
  </div>
</div>
@endsection